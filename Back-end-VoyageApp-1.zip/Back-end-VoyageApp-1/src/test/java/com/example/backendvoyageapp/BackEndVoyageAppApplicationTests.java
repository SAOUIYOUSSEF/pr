package com.example.backendvoyageapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackEndVoyageAppApplicationTests {

    @Test
    void contextLoads() {
    }

}
