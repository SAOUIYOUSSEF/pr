package com.example.backendvoyageapp.configuration;

import static org.junit.jupiter.api.Assertions.*;

class WebSecurityConfigurationTest {

}