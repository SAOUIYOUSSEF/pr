package com.example.backendvoyageapp.dto;

public record AuthenticationResponse(String jwtToken) {

}
