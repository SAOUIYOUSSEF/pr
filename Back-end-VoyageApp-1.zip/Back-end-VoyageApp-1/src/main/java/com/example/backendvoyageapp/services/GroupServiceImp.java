package com.example.backendvoyageapp.services;

import com.example.backendvoyageapp.dto.GroupDto;
import com.example.backendvoyageapp.mappers.GroupMapper;
import com.example.backendvoyageapp.models.Group;
import com.example.backendvoyageapp.repositories.GroupRepository;
import org.hibernate.service.spi.ServiceException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.stereotype.Service;
import java.util.Optional;

@Service
public class GroupServiceImp implements GroupService{
    private final GroupMapper groupMapper;
    private final GroupRepository groupRepository ;
    @Autowired
    public GroupServiceImp(GroupRepository groupRepository, GroupMapper groupMapper) {
        this.groupRepository = groupRepository;
        this.groupMapper = groupMapper;
    }
    @Override
    public GroupDto getGroupById(Long id) {
        Group group = groupRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Group not found for id: " + id));

        return groupMapper.fromGroupToGroupDto(group);

      }




    @Override
    public GroupDto createGroup(GroupDto groupDto) {
       Group group= groupRepository.save(groupMapper.fromGroupDtoToGroup(groupDto));
        return groupMapper.fromGroupToGroupDto(group);

    }

    @Override
    public void deleteGroup(Long id) {
        try {
            groupRepository.deleteById(id);

        }catch (EmptyResultDataAccessException e) {
            throw new ResourceNotFoundException("Group not found for id: " + id);
        } catch (Exception e) {
            throw new ServiceException("An error occurred while deleting the group", e);
        }
    }

    @Override
    public GroupDto updateGroup(Long id, GroupDto updatedGroupDto) {
      try {
          Optional<Group> optionalGroup = groupRepository.findById(id);

          if (optionalGroup.isPresent()) {
              Group existingGroup = optionalGroup.get();
              Group updatedGroupData = groupMapper.fromGroupDtoToGroup(updatedGroupDto);
              existingGroup.setCode(updatedGroupData.getCode());
              existingGroup.setName(updatedGroupData.getName());
              Group updatedGroup = groupRepository.save(existingGroup);

              return groupMapper.fromGroupToGroupDto(updatedGroup);
          } else {
              throw new ResourceNotFoundException("Group not found for id: " + id);
          }
      } catch (EmptyResultDataAccessException e) {
          throw new ResourceNotFoundException("Group not found for id: " + id);
      } catch (Exception e) {
          throw new ServiceException("An error occurred while updating the group", e);
      }
    }


}



