package com.example.backendvoyageapp.mappers;

import com.example.backendvoyageapp.dto.GroupDto;
import com.example.backendvoyageapp.models.Group;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Component
public class GroupMapper {
    private final ModelMapper modelMapper =new ModelMapper();

    public GroupDto fromGroupToGroupDto(Group group){
        return modelMapper.map(group,GroupDto.class);
    }
    public Group fromGroupDtoToGroup(GroupDto groupDto){
        return modelMapper.map(groupDto,Group.class);
    }
}
