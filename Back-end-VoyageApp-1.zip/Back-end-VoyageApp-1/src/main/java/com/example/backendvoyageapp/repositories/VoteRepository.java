package com.example.backendvoyageapp.repositories;

import com.example.backendvoyageapp.models.Vote;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VoteRepository extends JpaRepository<Vote,Long> {
}
