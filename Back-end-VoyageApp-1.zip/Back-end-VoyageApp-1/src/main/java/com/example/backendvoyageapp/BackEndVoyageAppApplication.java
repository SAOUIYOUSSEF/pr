package com.example.backendvoyageapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackEndVoyageAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(BackEndVoyageAppApplication.class, args);
    }

}
