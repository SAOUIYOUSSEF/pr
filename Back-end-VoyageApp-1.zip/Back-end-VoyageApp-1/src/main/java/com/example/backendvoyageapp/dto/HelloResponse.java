package com.example.backendvoyageapp.dto;

public record HelloResponse(String message) {
}
