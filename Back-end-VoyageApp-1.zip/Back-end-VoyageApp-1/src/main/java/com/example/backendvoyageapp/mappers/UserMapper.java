package com.example.backendvoyageapp.mappers;

import com.example.backendvoyageapp.dto.UserDto;
import com.example.backendvoyageapp.models.User;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Component
public class UserMapper {

    private final ModelMapper modelMapper =new ModelMapper() ;
    public UserDto fromUserToUserDto(User user){
        return  modelMapper.map(user,UserDto.class);
    }
    public User fromUserDtoToUser(UserDto userDto){
        return modelMapper.map(userDto,User.class);
    }
}
