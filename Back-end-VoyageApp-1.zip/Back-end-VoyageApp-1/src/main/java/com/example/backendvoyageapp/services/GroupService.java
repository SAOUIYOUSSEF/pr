package com.example.backendvoyageapp.services;

import com.example.backendvoyageapp.dto.GroupDto;

public interface GroupService {
    
    GroupDto createGroup(GroupDto groupDto);

    void deleteGroup(Long id);

    GroupDto updateGroup(Long id, GroupDto updatedGroupDto);

    GroupDto getGroupById(Long id);
}
