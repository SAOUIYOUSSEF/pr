package com.example.backendvoyageapp.services;

import com.example.backendvoyageapp.dto.UserDto;
import com.example.backendvoyageapp.mappers.UserMapper;
import com.example.backendvoyageapp.models.Group;
import com.example.backendvoyageapp.models.Role;
import com.example.backendvoyageapp.models.User;
import com.example.backendvoyageapp.repositories.GroupRepository;
import com.example.backendvoyageapp.repositories.RoleRepository;
import com.example.backendvoyageapp.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class UserServiceImp implements UserService{

    @Autowired
    RoleRepository roleRepository;
    @Autowired
    BCryptPasswordEncoder bCryptPasswordEncoder;

   private final UserRepository userRepository ;
    private final GroupRepository groupRepository ;
    private final  UserMapper userMapper ;
    @Autowired
    public UserServiceImp(UserRepository userRepository, UserMapper userMapper,GroupRepository groupRepository) {
        this.userRepository = userRepository;
        this.userMapper = userMapper;
        this.groupRepository=groupRepository;
    }

    @Override
    public List<UserDto> GetAllUsersByGroupId(Long id) {
        Group group = groupRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Group not found for id: " + id));
        List<User> users=group.getUsers();
        return users.stream()
                .map(userMapper::fromUserToUserDto)
                .collect(Collectors.toList());
    }

    @Override
    public UserDto getUserById(Long id) {

           User user= userRepository.findById(id)
                   .orElseThrow(()-> new ResourceNotFoundException("user not found for id: " + id));
           return userMapper.fromUserToUserDto(user);

    }

    @Override
    public UserDto saveUser(UserDto userDto) {
        return null;
    }

    @Override
    public void deleteUser(Long id) {

    }
    @Override
    public User addRoleToUser(String username, String rolename) {
        User user = userRepository.findByUsername(username);
        Role role = roleRepository.findByRole(rolename);

        user.getRoles().add(role);
        return user;
    }
    @Override
    public Role addRole(Role role) {
        return roleRepository.save(role);
    }
}
