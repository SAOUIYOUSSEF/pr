package com.example.backendvoyageapp.configuration;

import com.example.backendvoyageapp.dto.UserDto;
import com.example.backendvoyageapp.models.User;
import com.example.backendvoyageapp.services.UserService;
import jakarta.servlet.FilterChain;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
public class MyUserDetailsService implements UserDetailsService {
    @Autowired
    UserService userService;


    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        UserDto user = userService.findUserByUsername(username);
        if (user==null)
            throw new UsernameNotFoundException("User not Found");
        else {
            List<GrantedAuthority> authorities = new ArrayList<>();
            user.getRoles().forEach(role -> {
                GrantedAuthority authority = new SimpleGrantedAuthority(role.getRole());
                authorities.add(authority);
            } );

            return new org.springframework.security.core.userdetails.User(user.getUsername(),user.getPassword(),authorities);
        }
    }

    @Override
    protected void successfulAuthentication(HttpServletRequest request, HttpServletResponse response, FilterChain chai
org.springframework.security.core.userdetails.User user = (org.springframework.security.core.userdetails.User) authResult.getPrincipal();
    List<String> roles = new ArrayList<>();
    user.getAuthorities().forEach(a->{
        roles.add (a.getAuthority());
        ｝）;
        String jwt = JWT.create()
                .withSubject(user.getUsername())
                . withArrayClaim( name: "roles", roles. toArray(new String[roles.size()]))
        .withExpiresAt(new Date(System.currentTimeMillis()+).
}
