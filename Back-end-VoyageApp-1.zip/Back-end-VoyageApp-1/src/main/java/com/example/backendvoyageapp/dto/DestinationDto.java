package com.example.backendvoyageapp.dto;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class DestinationDto {
    private Long id ;
    private String username ;
    private String location ;
}

