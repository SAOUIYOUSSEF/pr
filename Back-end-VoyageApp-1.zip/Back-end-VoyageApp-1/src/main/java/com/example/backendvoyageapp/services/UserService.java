package com.example.backendvoyageapp.services;

import com.example.backendvoyageapp.dto.UserDto;
import com.example.backendvoyageapp.models.Role;
import com.example.backendvoyageapp.models.User;

import java.util.List;

public interface UserService  {
    List<UserDto> GetAllUsersByGroupId(Long id);

    UserDto getUserById(Long id);

    UserDto saveUser(UserDto userDto);

    void deleteUser(Long id);

    UserDto findUserByUsername(String username);

    Role addRole(Role role);
    UserDto addRoleToUser(String username, String rolename);
    List<User> findAllUsers();

}
