package security;

public class SecurityParameters {

public static final long EXPIRATION_TIME = 3*24*60*60*1000;

public static final String SECRET = "secret";

public static final String PREFIX = "BEARER" ;
}
